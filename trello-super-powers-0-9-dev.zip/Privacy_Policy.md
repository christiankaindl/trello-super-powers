# Trello Super Powers Privacy Policy

Trello Super Powers does not collect any user information/data. Trello Super Powers only saves users preferences, nothing is ever synchronized to Trello Super Powers servers. Preferences may be synchronized with Firefox/Mozilla servers when the user uses Firefox Sync.

Trello Super Powers also does not collect any information from your Trello boards.
